package com.example.myprofile.ui.series

class SerieSelected {
}