package com.example.myprofile.ui.series

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyStaggeredGridScope
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.material.BottomNavigation
import androidx.compose.material.BottomNavigationItem
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.currentBackStackEntryAsState
import coil.compose.AsyncImage
import com.example.myprofile.R
import com.example.myprofile.ui.models.Serie

@Composable
fun Serie(navController: NavController, viewModel: SerieViewModel) {
    val listeSerie = viewModel.series.collectAsState()

    ScaffoldApp(navController, listeSerie.value)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScaffoldApp(navController : NavController, series : List<Serie>) {
    //var presses by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(70.dp),
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                navigationIcon = {
                    IconButton(onClick = { /* do something */ }) {
                        Icon(
                            modifier = Modifier.padding(start = 10.dp, end = 10.dp),
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Localized description"
                        )
                    }
                },
                title = {
                    Text("Movie's App")
                },
                actions = {
                    IconButton(onClick = { /* do something */ }) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "Localized description"
                        )
                    }
                }
            )

        },
        bottomBar = {
            BottomNavigation {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                BottomNavigationItem(
                    icon = { Icon(painter = painterResource(R.drawable.camera_video), contentDescription = "film") },
                    label = { Text(text = "Films") },
                    selected = currentDestination?.hierarchy?.any {true} == true,
                    onClick = { navController.navigate("home") }
                )

                BottomNavigationItem(
                    icon = { Icon(painter = painterResource(R.drawable.video), contentDescription = "série") },
                    label = { Text(text = "Séries") },
                    selected = currentDestination?.hierarchy?.any {true} == true,
                    onClick = { navController.navigate("screen") }
                )

                BottomNavigationItem(
                    icon = { Icon(painter = painterResource(R.drawable.acteur), contentDescription = "acteur") },
                    label = { Text(text = "Acteurs") },
                    selected = currentDestination?.hierarchy?.any {true} == true,
                    onClick = { navController.navigate("acteur") }
                )
            }
        }

    ) { innerPadding ->
        LazyVerticalGrid(modifier = Modifier
            .padding(innerPadding), columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(15.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {

            items(series) { serie ->
                Card() {
                    Column() {
                        AsyncImage(
                            model = "https://image.tmdb.org/t/p/w500/" + serie.backdrop_path,
                            contentDescription = null,
                        )
                        Text(
                            text = serie.name,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Default
                        )
                        Text(
                            text = serie.first_air_date,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Default
                        )
                    }
                }
            }
        }

    }
}